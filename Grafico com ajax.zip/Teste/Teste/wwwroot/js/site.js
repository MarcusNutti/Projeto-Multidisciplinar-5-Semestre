﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
setInterval(function () {
    $.ajax({
        url: "api/PegaDados",
        success: function (dados) {

            var dataPoints = [];

            var result = JSON.parse(dados);

            for (var i = 0; i < result.length; i++) {
                dataPoints.push({ label: result[i].label, y: result[i].y });
            }

            var chart = new CanvasJS.Chart("chartContainer", {
                backgroundColor: "#cdd1d0",
                theme: "light2",
                animationEnabled: true,
                zoomEnabled: true,

                title: {
                    text: "Quantidade de chuva por dia",
                    fontColor: "#000000",
                    fontSize: 25,
                    padding: 10,
                    margin: 15,
                    fontWeight: "bold"
                },
                data: [
                    {
                        type: "spline",
                        color: "#009879",
                        dataPoints: dataPoints,
                    }
                ]
            });
            chart.render();
        }
    })
}, 10000)