﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Web;

namespace Teste.Models
{
	[DataContract]
	public class ChartViewModel
    {
		public ChartViewModel(DateTime x, int  y)
			{
				this.label = x.ToString();
				this.Y = y;
			}

        public ChartViewModel()
        {
        }

        //Explicitly setting the name to be used while serializing to JSON.
        [DataMember(Name = "label")]
			public string label = null;

			//Explicitly setting the name to be used while serializing to JSON.
			[DataMember(Name = "y")]
			public Nullable<int> Y = null;



	}
}
