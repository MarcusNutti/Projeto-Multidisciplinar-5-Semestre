﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Teste.DAO;
using Newtonsoft.Json;
using Teste.Models;
using System.Web;


namespace Teste.Controllers
{
    public class ChartController : Controller
    {
		private ChartDAO dao= new ChartDAO();

		[HttpGet("api/PegaDados")]
		public IActionResult GetData() 
		{
			try
			{
				List<ChartViewModel> dataPoints = dao.Listagem();

				return Json(JsonConvert.SerializeObject(dataPoints, _jsonSetting));
			}
			catch (Exception)
			{
				return View("Error");
			}
		}

		public ActionResult Index()
		{
			try
			{	List<ChartViewModel> dataPoints = dao.Listagem();
				ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints,_jsonSetting);

				return View();
			}
			catch (Exception)
			{
				return View("Error");
			}
		}
		JsonSerializerSettings _jsonSetting = new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore };
	}
}

