﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Teste.Models;
using Teste.DAO;

namespace Teste.DAO
{
    public class ChartDAO
    {
        private SqlParameter[] CriaParamentros(ChartViewModel Chart)
        {
            SqlParameter[] parametros =
                { 
                    new SqlParameter("Dia",Chart.label),
                    new SqlParameter("chuva",Chart.Y)
                };
            return parametros;
        }
        private ChartViewModel MontaModel(DataRow registro)
        {
            ChartViewModel c = new ChartViewModel();
            c.label = Convert.ToDateTime((registro["Dia"])).ToString("dd/MM/yyyy");
            c.Y=Convert.ToInt32(registro["chuva"]);
            return c;
        }


        public List<ChartViewModel> Listagem()
        {
            List<ChartViewModel> lista = new List<ChartViewModel>();

            string sql = "select * from fake order by 1";
            DataTable tabela = HelperDAO.ExecutaSelect(sql, null);

            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaModel(registro));
            return lista;
        }
    }
}
