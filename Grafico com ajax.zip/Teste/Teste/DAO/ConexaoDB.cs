﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Teste.DAO
{
    public class ConexaoDB
    {
        public static SqlConnection GetConexao()
        {
            string cx = "Data Source=localhost; Initial Catalog=teste; user id=sa; password=123456";
            SqlConnection conexao = new SqlConnection(cx);
            conexao.Open();
            return conexao;
        }
    }
}
